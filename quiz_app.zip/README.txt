# Simple Quiz App

## Overview

A simple command-line quiz application.

## Features

- Multiple-choice questions.
- Score tracking.

## Technologies Used

- C++

## How to Run

1. Compile the program: `g++ quiz_app.cpp -o quiz_app`

2. Run the program: `./quiz_app`